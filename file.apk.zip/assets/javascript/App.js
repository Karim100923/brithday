/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

/**
 *  A static JavaScript object that represents the Acrobat application. It defines a number
 *  of Acrobat-specific functions plus a variety of utility routines and convenience functions.
 *
 *  @class App
 */
function App() { };

App.prototype =
{
	/**
     *  The platform the script is currently executing on.
     *
     *  @property platform
     *  @type {String}
     *  @readOnly
     */
	get platform()
	{
		return window._app.getPlatform();
	},
	
	/**
     *  The language code of the running application.
     *
     *  @property language
     *  @type {String}
     *  @readOnly
     */
	get language()
	{
		return window._app.getLanguage();
	}
};

/**
 *  Displays an alert dialog box.
 *
 *  @method alert
 *  @param cMsg {String} A string containing the message to be displayed.
 */
App.prototype.alert = function(cMsg, nIcon)
{
    return window._app.alert(cMsg + "", nIcon);
};
   
/**
 *  [Unimplemented]
 *
 *  @private
 *  @method beep
 *  @param nType {Number}
 */
App.prototype.beep = function(nType)
{
    return window._app.beep(nType);
};

//register undefined properties on the App.prototype object
registerUndefinedProperty(App.prototype, 'app', 'activeDocs');
registerUndefinedProperty(App.prototype, 'app', 'calculate');
registerUndefinedProperty(App.prototype, 'app', 'constants');
registerUndefinedProperty(App.prototype, 'app', 'focusRect');
registerUndefinedProperty(App.prototype, 'app', 'formsVersion');
registerUndefinedProperty(App.prototype, 'app', 'fromPDFConverters');
registerUndefinedProperty(App.prototype, 'app', 'fs');
registerUndefinedProperty(App.prototype, 'app', 'fullscreen');
registerUndefinedProperty(App.prototype, 'app', 'media');
registerUndefinedProperty(App.prototype, 'app', 'monitors');
registerUndefinedProperty(App.prototype, 'app', 'numPlugIns');
registerUndefinedProperty(App.prototype, 'app', 'openInPlace');
registerUndefinedProperty(App.prototype, 'app', 'plugIns');
registerUndefinedProperty(App.prototype, 'app', 'printColorProfiles');
registerUndefinedProperty(App.prototype, 'app', 'printerNames');
registerUndefinedProperty(App.prototype, 'app', 'runtimeHighlight');
registerUndefinedProperty(App.prototype, 'app', 'runtimeHighlightColor');
registerUndefinedProperty(App.prototype, 'app', 'thermometer');
registerUndefinedProperty(App.prototype, 'app', 'toolbar');
registerUndefinedProperty(App.prototype, 'app', 'toolbarHorizontal');
registerUndefinedProperty(App.prototype, 'app', 'toolbarVertical');
registerUndefinedProperty(App.prototype, 'app', 'viewerType');
registerUndefinedProperty(App.prototype, 'app', 'viewerVariation');
registerUndefinedProperty(App.prototype, 'app', 'viewerVersion');

// instantiate object
var app = new App();
