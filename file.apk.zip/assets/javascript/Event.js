/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

/**
 *  All JavaScript scripts are executed as the result of a particular event. For each of
 *  these events, JavaScript creates an event object. During the occurrence of each event,
 *  you can access this object to get and possibly manipulate information about the current
 *  state of the event.
 *
 *  @class Event
 */
function Event()
{
};

Event.prototype =
{
	/**
     *  Used for validation. Indicates whether a particular event in the event chain should 
     *  succeed. Set to false to prevent a change from occurring or a value from committing. 
     *  The default is true.
     *
     *  @property rc
     *  @type {Boolean}
     *  
     */ 
    get rc()
    {
        var result = window._event.getRC();
        
        if (result == 1)
            return true;
        else
            return false;
    },
    set rc(_val)
    {
        window._event.setRC(_val);
    },
    
    /**
     *  A string specifying the change in value that the user has just typed. A JavaScript may 
     *  replace part or all of this string with different characters. The change may take the form 
     *  of an individual keystroke or a string of characters (for example, if a paste into the field 
     *  is performed).
     *
     *  @property change
     *  @type {String}
     */
    get change()
    {
        return window._event.getChange();
    },
    set change(_val)
    {
        window._event.setChange(_val);
    },
    
    /**
     *  The target object that triggered the event. In all mouse, focus, blur, calculate, validate, and 
     *  format events, it is the Field object that triggered the event. In other events, such as page open 
     *  and close, it is the Doc or this object.
     *
     *  @property target
     *  @type {Object}
     *  @readOnly
     */
    get target()
    {
    	var ret;
    
    	var name = window._event.getTarget();
    	if (!isNullOrUndefined(name))
    	{
    		ret = new Field(name);
    	}
    	
    	return ret;
    },
    
    /**
     *  The starting position of the current text selection during a keystroke event.
     *
     *  @property selStart
     *  @type {Number}
     *  @readOnly
     */
    get selStart()
    {
        return window._event.getSelStart();
    },
 
    /**
     *  The ending position of the current text selection during a keystroke event.
     *
     *  @property selEnd
     *  @type {Number}
     *  @readOnly
     */ 
    get selEnd()
    {
        return window._event.getSelEnd();
    },
    
    /**
     *  This property has different meanings for different field events:
     *
     *    For the Field/Validate event, it is the value that the field contains when it is committed. 
     *    For a combo box, it is the face value, not the export value.
     *
     *    For a Field/Calculate event, JavaScript should set this property. It is the value that the 
     *    field should take upon completion of the event.
     *
     *    For a Field/Format event, JavaScript should set this property. It is the value used when generating 
     *    the appearance for the field. By default, it contains the value that the user has committed. For a 
     *    combo box, this is the face value, not the export value.
     *
     *    For a Field/Keystroke event, it is the current value of the field. If modifying a text field, for 
     *    example, this is the text in the text field before the keystroke is applied.
     *
     *    For Field/Blur and Field/Focus events, it is the current value of the field. During these two events, 
     *    event.value is read only. That is, the field value cannot be changed by setting event.value.
     *
     *  @property value
     *  @type {Any}
     */
    get value()
    {
        return window._event.getValue();
    },
    set value(_val)
    {
        window._event.setValue(_val);
    },
    
    /**
     *  Verifies the current keystroke event before the data is committed. It can be used to check target form 
     *  field values to verify, for example, whether character data was entered instead of numeric data. JavaScript 
     *  sets this property to true after the last keystroke event and before the field is validated.
     *
     *  @property willCommit
     *  @type {Boolean}
     *  @readOnly
     */
    get willCommit()
    {
        var result = window._event.getWillCommit();
        
        if (result == 1)
            return true;
        else
            return false;
    },
     
    /**
     *  Returns true if errors should be silenced instead of displaying an alert.
     *
     *  @private
     *  @property silenceErrors
     *  @type {Boolean}
     *  @readOnly
     */
    get silenceErrors()
    {
        var result = window._event.getSilenceErrors();
        
        if (result == 1)
            return true;
        else
            return false;
    },
    
    /**
     *  Tries to return the name of the target object. Can be used for debugging purposes to help identify 
     *  the code causing exceptions to be thrown. Common values of targetName include:
     *
     *    The folder-level script file name for App/Init events
     *    The document-level script name forDoc/Open events
     *    The PDF file name being processed for Batch/Exec events
     *    The field name for Field events
     *    The menu item name for Menu/Exec events
     *    The screen annotation name for Screen events (multimedia events)
     *  
     *  @property targetName
     *  @type {String}
     *  @readOnly
     */
    get targetName()
    {
        return window._event.getTargetName();
    },
    
    /**
     *  The Field object that triggered the calculation event. This object is usually different from the
     *  target of the event, which is the field that is being calculated.
     *
     *  @property source
     *  @type {Object}
     *  @readOnly
     */
    get source()
    {
        var ret;
    
        var name = window._event.getSource();
        if (! isNullOrUndefined(name))
        {
            ret = new Field(name);
        }
        
        return ret;
    }
};

//register undefined properties on the Event.prototype object
registerUndefinedProperty(Event.prototype, 'event', 'changeEx');
registerUndefinedProperty(Event.prototype, 'event', 'commitKey');
registerUndefinedProperty(Event.prototype, 'event', 'fieldFull');
registerUndefinedProperty(Event.prototype, 'event', 'keyDown');
registerUndefinedProperty(Event.prototype, 'event', 'modifier');
registerUndefinedProperty(Event.prototype, 'event', 'name');
registerUndefinedProperty(Event.prototype, 'event', 'richChange');
registerUndefinedProperty(Event.prototype, 'event', 'richChangeEx');
registerUndefinedProperty(Event.prototype, 'event', 'richValue');
registerUndefinedProperty(Event.prototype, 'event', 'shift');
registerUndefinedProperty(Event.prototype, 'event', 'type');

// instantiate object
var event = new Event();
