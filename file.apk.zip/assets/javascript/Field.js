/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

/**
 *  This object represents an Acrobat form field (that is, a field created using the Acrobat
 *  form tool or the Doc addField method). In the same manner that a form author can modify an
 *  existing field's properties, the JavaScript user can use the Field object to perform the
 *  same modifications.
 *
 *  @class Field
 *  @param name {String} The name of the field.
 */
function Field(name)
{
    this.name = name;
};

Field.prototype = 
{    
	/**
     *  Returns the type of the field as a string.
     *
     *  @property type
     *  @type {String}
     *  @readonly
     */
    get type()
    {
        return window._field.getType(this.name);
    },
	    
	/**
     *  The value of the field data that the user has entered. Depending on the type of the field, 
     *  may be a String, Date, or Number. Typically, the value is used to create calculated fields.
     *
     *  @property value
     *  @type {Any}
     */
    get value()
    {
    	var val = window._field.getValue(this.name);
    	if ((window._field.isNumberFormatType(this.name) || !isNaN(val)) && val != "")
    		val = parseFloat(val);
    		
    	return val;
    },
    set value(_val)
    {
    	window._field.setValue(_val, this.name);
    },
    
    /**
     *  The foreground color of a field. It represents the text color for text, button, 
     *  or list box fields and the check color for check box or radio button fields.  Values
     *  are defined by Color arrays.
     *
     *  @private
     *  @property textColor
     *  @type {Object}
     */
    set textColor(_textColor)
    {
    	if (_textColor.length >= 2 && typeof _textColor[0] == "string" && _textColor[0] == "G" && 
    		typeof _textColor[1] == "number")
    	{
    		window._field.setGrayTextColor(_textColor[1], this.name);
    	}
    	else if (_textColor.length >= 4 && typeof _textColor[0] == "string" && _textColor[0] == "RGB" &&
    			 typeof _textColor[1] == "number" && typeof _textColor[2] == "number" && typeof _textColor[3] == "number")
    	{
    		window._field.setRGBTextColor(_textColor[1], _textColor[2], _textColor[3], this.name);
    	}
    }
};

/**
 *  Gets the array of terminal child fields (that is, fields that can have a value) for 
 *  this Field object, the parent field.
 *
 *  @method getArray
 *  @return {Object} An array of Field objects.
 */
Field.prototype.getArray = function()
{
	var returnVal;
	
	// get the comma separated field names from native
	var fieldNames = window._field.getArray(this.name);
	
	if (!isNullOrUndefined(fieldNames) && fieldNames.length > 0)
	{
		returnVal = new Array();
		
		// split the comma separate field names and create field object
		// using each field name
		var fieldNameArray = fieldNames.split(",");
		for (var i = 0; i<fieldNameArray.length; i++)
		{
			returnVal[i] = new Field(fieldNameArray[i]);
		}
	}
	return returnVal;
};

/**
 *  Sets the focus to this field. This can involve changing the page that the user is 
 *  currently on or causing the view to scroll to a new position in the document.
 *
 *  @method setFocus
 */
Field.prototype.setFocus = function()
{
    window._field.setFocus(this.name);
};

//register undefined properties on the Field.prototype object
registerUndefinedProperty(Field.prototype, 'Field', 'alignment');
registerUndefinedProperty(Field.prototype, 'Field', 'borderStyle');
registerUndefinedProperty(Field.prototype, 'Field', 'buttonAlignX');
registerUndefinedProperty(Field.prototype, 'Field', 'buttonAlignY');
registerUndefinedProperty(Field.prototype, 'Field', 'buttonFitBounds');
registerUndefinedProperty(Field.prototype, 'Field', 'buttonPosition');
registerUndefinedProperty(Field.prototype, 'Field', 'buttonScaleHow');
registerUndefinedProperty(Field.prototype, 'Field', 'buttonScaleWhen');
registerUndefinedProperty(Field.prototype, 'Field', 'calcOrderIndex');
registerUndefinedProperty(Field.prototype, 'Field', 'charLimit');
registerUndefinedProperty(Field.prototype, 'Field', 'comb');
registerUndefinedProperty(Field.prototype, 'Field', 'commitOnSelChange');
registerUndefinedProperty(Field.prototype, 'Field', 'currentValueIndices');
registerUndefinedProperty(Field.prototype, 'Field', 'defaultStyle');
registerUndefinedProperty(Field.prototype, 'Field', 'defaultValue');
registerUndefinedProperty(Field.prototype, 'Field', 'doNotScroll');
registerUndefinedProperty(Field.prototype, 'Field', 'doNotSpellCheck');
registerUndefinedProperty(Field.prototype, 'Field', 'delay');
registerUndefinedProperty(Field.prototype, 'Field', 'display');
registerUndefinedProperty(Field.prototype, 'Field', 'doc');
registerUndefinedProperty(Field.prototype, 'Field', 'editable');
registerUndefinedProperty(Field.prototype, 'Field', 'exportValues');
registerUndefinedProperty(Field.prototype, 'Field', 'fileSelect');
registerUndefinedProperty(Field.prototype, 'Field', 'fillColor');
registerUndefinedProperty(Field.prototype, 'Field', 'hidden');
registerUndefinedProperty(Field.prototype, 'Field', 'highlight');
registerUndefinedProperty(Field.prototype, 'Field', 'lineWidth');
registerUndefinedProperty(Field.prototype, 'Field', 'multiline');
registerUndefinedProperty(Field.prototype, 'Field', 'multipleSelection');
registerUndefinedProperty(Field.prototype, 'Field', 'numItems');
registerUndefinedProperty(Field.prototype, 'Field', 'page');
registerUndefinedProperty(Field.prototype, 'Field', 'password');
registerUndefinedProperty(Field.prototype, 'Field', 'print');
registerUndefinedProperty(Field.prototype, 'Field', 'radiosInUnison');
registerUndefinedProperty(Field.prototype, 'Field', 'readonly');
registerUndefinedProperty(Field.prototype, 'Field', 'rect');
registerUndefinedProperty(Field.prototype, 'Field', 'required');
registerUndefinedProperty(Field.prototype, 'Field', 'richText');
registerUndefinedProperty(Field.prototype, 'Field', 'richValue');
registerUndefinedProperty(Field.prototype, 'Field', 'rotation');
registerUndefinedProperty(Field.prototype, 'Field', 'strokeColor');
registerUndefinedProperty(Field.prototype, 'Field', 'style');
registerUndefinedProperty(Field.prototype, 'Field', 'submitName');
registerUndefinedProperty(Field.prototype, 'Field', 'textFont');
registerUndefinedProperty(Field.prototype, 'Field', 'textSize');
registerUndefinedProperty(Field.prototype, 'Field', 'userName');
registerUndefinedProperty(Field.prototype, 'Field', 'valueAsString');
