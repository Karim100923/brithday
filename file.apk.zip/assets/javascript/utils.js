/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

/**
 *  A collection of private global javascript utility methods.
 */

/**
 *  Registers an undefined property on a javascript object.  This is useful because javascript
 *  does not throw on undefined property access, yet we may want to track access to said properties.
 *  This method registers a getter and a setter for the passed in property name for the passed in
 *  object.  Both the getter and the setter throw a ReferenceError that can be caught and processed.
 *
 *  @private
 *  @method registerUndefinedProperty
 *  @param object {Object} The object whose undefined property is to be registered.
 *  @param objectName {String} The name to use for the object when throwing a ReferenceError.
 *  @param propertyName {String} The undefined property name to register.
 */
function registerUndefinedProperty(object, objectName, propertyName)
{
    Object.defineProperty(object, propertyName,
    {
        get: function()
        {
            throw new ReferenceError("Can't get property: '" + propertyName + "' for object: '" + objectName + "'");
        },
        set: function(_val)
        {
            throw new ReferenceError("Can't set property: '" + propertyName + "' for object: '" + objectName + "'");
        }
    });
};
