/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

/**
 *  Gets a localized resource string.
 *
 *  @private
 *  @class EScriptString
 *  @constructor
 */
function EScriptString() { };
    
/**
 *  Gets a localized resource string.
 *
 *  @private
 *  @method get
 *  @param strID {String} String ID specifying which localized resource string to get.
 *  @return {String} Localized resource string.
 */
EScriptString.get = function(strID)
{
    return window._escriptString.get(strID);
};