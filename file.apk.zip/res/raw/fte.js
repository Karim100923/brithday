document.addEventListener('DOMContentLoaded', function() {

     var currentPage = 0;

     var currWidth = document.documentElement.clientWidth; 
     var currHeight = document.documentElement.clientHeight; 
     var isPhone = false;
     var is2XPixels = false;

     // maybe this should be <= 468px
     if( currWidth <= 568)
          isPhone = true;

     if( window.devicePixelRatio >= 2)
          is2XPixels = true;

     initializeFTE();


     function initializeFTE() { 

          showWelcomeScreen();
          showProgressArea();
          updateProgressArea();
     }
     
     function showWelcomeScreen() {
          
          var tip1Laptop = document.getElementById('tip1-Laptop');
          tip1Laptop.classList.add("endLocation");

          var tip1Android = document.getElementById('tip1-Android');
          tip1Android.classList.add("endLocation");

          var tip1iPhone = document.getElementById('tip1-iPhone');
          tip1iPhone.classList.add("endLocation");

          var tip1 = document.getElementById('tip1Text');
          //tip1.innerHTML = window.devicePixelRatio + " " + isPhone + " w: " + currWidth + " h: " + currHeight;
          tip1.classList.add("endLocation");
     }

    function hideWelcomeScreen() {

          // NOTE: In original shipping version, transitionDelay was set to 0.
          // This stopped working, so I have changed the transitionDelay to '0s'.
          var tip1Laptop = document.getElementById('tip1-Laptop');
          tip1Laptop.style.transitionDelay = '0s';
          tip1Laptop.style.transitionDuration = '.25s';
          tip1Laptop.classList.remove("endLocation");

          var tip1Android = document.getElementById('tip1-Android');
          tip1Android.style.transitionDelay = '0s';
          tip1Android.style.transitionDuration = '.25s';
          tip1Android.classList.remove("endLocation");

          var tip1iPhone = document.getElementById('tip1-iPhone');
          tip1iPhone.style.transitionDelay = '0s';
          tip1iPhone.style.transitionDuration = '.25s';
          tip1iPhone.classList.remove("endLocation");

          // NOTE: In original shipping version, transitionDuration wasn't changed.
          // After changes above, it looked better to speed up the text transition duration.
          var tip1 = document.getElementById('tip1Text');
          //tip1.classList.remove("endLocation");
          tip1.style.transitionDelay = '0s';
          tip1.style.transitionDuration = '.25s';
          tip1.classList.add("outLocation");
     }

     function showProgressArea() {

          var progressArea = document.getElementById('progressArea');
          progressArea.classList.add('fade-in-element');
     }

     function updateProgressArea() {

          if( currentPage == 0) {

               var currentPageCircle = document.getElementById('progressCircleFirst');
               currentPageCircle.classList.add('selected');

               var secondPageCircle = document.getElementById('progressCircleSecond');
               secondPageCircle.style.left = "15px";

               var thirdPageCircle = document.getElementById('progressCircleThird');
               thirdPageCircle.style.left = "25px";
          }

          // second circle selected
          else if ( currentPage == 1) {

               var currentPageCircle = document.getElementById('progressCircleSecond');
               currentPageCircle.classList.add('selected');
               // -5 from previous
               currentPageCircle.style.left = "10px";

               var prevCircle = document.getElementById('progressCircleFirst');
               prevCircle.classList.remove("selected");
          }

          // third circle selected
          else if ( currentPage == 2) {

               var currentPageCircle = document.getElementById('progressCircleThird');
               currentPageCircle.classList.add("selected");
               // -5 from previous left
               currentPageCircle.style.left = "20px";

               var prevCircle = document.getElementById('progressCircleSecond');
               prevCircle.style.left = "10px";
               prevCircle.classList.remove("selected");
          }
     }

     /* **************************************** */
     /*           Tap and Swipe Events           */
     /* **************************************** */

     var startX = 0;
     var dist = 0;
     var minSwipeDist = 20;
     var isSwiping = false;

     var tipScreen = document.getElementById("tipScreen");
     
     // SWIPE
     tipScreen.addEventListener('touchstart', function(e) {

          isSwiping = true;
          dist = 0;
          var touchObj = e.changedTouches[0]; // store first touch point
          startX = parseInt(touchObj.clientX); // get x position
          e.preventDefault();

     }, false);

     tipScreen.addEventListener('touchmove', function(e) {

          var touchObj = e.changedTouches[0]; // store first touch point
          dist = parseInt(touchObj.clientX) - startX;
          e.preventDefault();

     }, false);

     tipScreen.addEventListener('touchend', function(e) {

          isSwiping = false;

          var touchObj = e.changedTouches[0]; // store first touch point
          e.preventDefault();
          
          // SWIPING
          if( Math.abs(dist) > minSwipeDist)
          {
               // previous (slide positive/right)
               if( dist > 0 ) {

                    if( currentPage == 2)
                         showPage2("previous");

                    else if( currentPage == 1)
                         showPage1("previous"); 
               }

               // next (slide negative/left)
               else {
                    
                    if( currentPage == 0)
                         showPage2("next");

                    else if( currentPage == 1)
                         showPage3("next");    
               }
          }

          // TAPPING - only go forward
          else {
               
               if( currentPage == 0)
                    showPage2("next");

               else if( currentPage == 1)
                    showPage3("next");    
          }


     }, false);



     function showPage1(direction) {

          // this should only happen when going backwards
          currentPage--;

          // first hide page 2 elements. 
          var tip2 = document.getElementById('tip2Text');
          tip2.classList.remove("endLocation");

          var tip2Gif = document.getElementById('tip2-ToolSwitcher');
          tip2Gif.classList.add("fade-out-gif");

          // then show the page 1 elements.
          var tip1Laptop = document.getElementById('tip1-Laptop');
          tip1Laptop.style.transitionDelay = '.5s';
          tip1Laptop.classList.add("endLocation");

          var tip1Android = document.getElementById('tip1-Android');
          tip1Android.style.transitionDelay = '.5s';
          tip1Android.classList.add("endLocation");

          var tip1iPhone = document.getElementById('tip1-iPhone');
          tip1iPhone.style.transitionDelay = '.5s';
          tip1iPhone.classList.add("endLocation");

          var tip1 = document.getElementById('tip1Text');
          // NOTE: transitionDelay was added after original shipping version.
          // The tip1 and tip2 text blocks were conflicting. 
          tip1.style.transitionDelay = '.5s';
          tip1.classList.remove("outLocation");


          // update page control area 
          var currentPageCircle = document.getElementById('progressCircleFirst');
          currentPageCircle.classList.add("selected");

          var secondPageCircle = document.getElementById('progressCircleSecond');
          secondPageCircle.classList.remove("selected");
          secondPageCircle.style.left = "15px";

          var thirdPageCircle = document.getElementById('progressCircleThird');
          thirdPageCircle.classList.remove("selected");
     }

     function showPage2(direction) {

          // going forward, came from page 1
          if( direction == "next") {
               currentPage++;
               hideWelcomeScreen();

               var tip2Image = document.getElementById('tip2-Image');
          
               if( !is2XPixels)
                    tip2Image.src = "../raw/screen2_phone.gif";
               else 
                    tip2Image.src = "../raw/screen2_tablet.gif";

               var tip2Gif = document.getElementById('tip2-ToolSwitcher');
               tip2Gif.classList.remove("fade-out-gif");              
               tip2Gif.classList.add("fade-in-gif");

               var tip2 = document.getElementById('tip2Text');
               tip2.classList.add("endLocation");

               updateProgressArea();
          }

          // going backwards, came from page 3
          else if( direction == "previous") {
               currentPage--;
               hidePage3();

               var currentPageCircle = document.getElementById('progressCircleSecond');
               currentPageCircle.classList.add("selected");

               var prevCircle = document.getElementById('progressCircleThird');
               prevCircle.classList.remove("selected");

               currentPageCircle.style.left = "10px";

               prevCircle.style.left = "25px";

               var tip2 = document.getElementById('tip2Text');
               tip2.classList.remove("outLocation");

               var tip2Gif = document.getElementById('tip2-ToolSwitcher');
               tip2Gif.classList.remove("fade-out-gif");
               tip2Gif.classList.add("fade-in-gif");
          }

     }

     function hidePage2() {

          var tip2Gif = document.getElementById('tip2-ToolSwitcher');
          //tip2Gif.classList.remove("fade-in-gif");
          tip2Gif.classList.add("fade-out-gif");

          var tip2 = document.getElementById('tip2Text');
          tip2.classList.add("outLocation");
     }

     function showPage3() {

          currentPage++;
          hidePage2();

          var tip3 = document.getElementById('tip3Text');
          tip3.classList.add("endLocation");

          var tip3Gif = document.getElementById('tip3-Connect');
          tip3Gif.classList.remove("fade-out-gif");
          tip3Gif.classList.add("fade-in-gif");

          var tip3Image = document.getElementById('tip3-Image');
          
         //if( isPhone)
          if( !is2XPixels)
               tip3Image.src = "../raw/screen3_android_phone.png";
          else
               tip3Image.src = "../raw/screen3_android_tablet.png";

          updateProgressArea();

          var progressArea = document.getElementById('progressArea');
          progressArea.classList.add("screen3");

          var continueButton = document.getElementById('continueButton');
          continueButton.classList.add("screen3");
          /* prevent left / buttons from overriding continueButton by bringing it forward */
          continueButton.style.zIndex = 1000;
     }

     function hidePage3() {

          var progressArea = document.getElementById('progressArea');
          progressArea.classList.remove("screen3");

          var continueButton = document.getElementById('continueButton');
          continueButton.classList.remove("screen3");

          var tip3Gif = document.getElementById('tip3-Connect');
          tip3Gif.classList.add("fade-out-gif");

          var tip3 = document.getElementById('tip3Text');
          tip3.classList.remove("endLocation");

     }

     /* OnClick event has a slight delay due to mobile browsers. Instead, send Continue event through here: */
     var continueBtn = document.getElementById("continueButton");
     continueBtn.addEventListener("touchend", handleTouchEndOnButton, false);

     function handleTouchEndOnButton(event) {

          var btn = document.getElementById("continueButton");
          btn.classList.remove('screen3');

          var progArea = document.getElementById("progressArea");
          progArea.classList.remove('screen3');
          progArea.classList.add('fade-out-element');

          var tip3 = document.getElementById('tip3Text');
          tip3.classList.add("fade-out-element");

          var tip3Gif = document.getElementById('tip3-Connect');
          tip3Gif.classList.add("fade-out-gif");

          // Application takes it from here:
          window.location.href='continue:';

          event.preventDefault();
          return false;
     }

     /* The onclick is passed to the application to handle, but try to hide things nicely here first. 
     document.getElementById("continueButton").onclick = function(e) {

          var btn = document.getElementById("continueButton");
          btn.classList.remove('screen3');

          var progArea = document.getElementById("progressArea");
          progArea.classList.remove('screen3');
          progArea.classList.add('fade-out-element');

          var tip3 = document.getElementById('tip3Text');
          tip3.classList.add("fade-out-element");

          var tip3Gif = document.getElementById('tip3-Connect');
          tip3Gif.classList.add("fade-out-gif");

          // Application takes it from here:
          window.location.href='continue:';

          e.preventDefault();
     } 
     */    


});

